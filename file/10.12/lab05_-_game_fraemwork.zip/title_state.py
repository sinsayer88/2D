import game_framework
from pico2d import *


name = "TitleState"
image = None


def enter():
    pass


def exit():
    pass


def handle_events():
    pass


def draw():
    pass







def update():
    pass


def pause():
    pass


def resume():
    pass






