from pico2d import *

open_canvas()

# fill here

close_canvas()
