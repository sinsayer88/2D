from pico2d import *

open_canvas()

grass = load_image('grass.png')
character = load_image('character.png')

# fill here
    
close_canvas()
